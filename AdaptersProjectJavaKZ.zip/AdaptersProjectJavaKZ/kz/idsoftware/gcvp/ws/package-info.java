@javax.xml.bind.annotation.XmlSchema(namespace = "http://ws.gcvp.idsoftware.kz/")
package kz.idsoftware.gcvp.ws;
