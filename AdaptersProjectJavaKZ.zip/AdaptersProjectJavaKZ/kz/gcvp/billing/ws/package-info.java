@javax.xml.bind.annotation.XmlSchema(namespace = "http://ws.billing.gcvp.kz/")
package kz.gcvp.billing.ws;
